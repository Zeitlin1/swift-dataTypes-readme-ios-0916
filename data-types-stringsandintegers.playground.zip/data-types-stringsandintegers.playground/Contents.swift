let thirdPlanet = "Earth"

var ninthPlanet: String

ninthPlanet = "Pluto"

let fifthPlanet: String = "Jupiter"
let sixthPlanet: String = "Saturn"
let seventhPlanet: String = "Uranus"

let numberOfCountriesInAfrica = 54

let numberOfMoonsOfSaturn = 62

print("There are \(numberOfMoonsOfSaturn) moons orbiting \(sixthPlanet)")